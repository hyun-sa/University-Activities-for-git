import sys


def LCS(a, b, l_a, l_b):
    length = [[0 for temp_1 in range(0, l_b+1)] for temp_2 in range(0, l_a+1)]
    lcs = [[[] for temp_1 in range(0, l_b+1)] for temp_2 in range(0, l_a+1)]
    for i in range(1, l_a+1):
        for j in range(1, l_b+1):
            if a[i-1] == b[j-1]:
                length[i][j] = length[i-1][j-1] + 1
                lcs[i][j] = lcs[i-1][j-1][:]
                lcs[i][j].append(b[j-1])
            else:
                length[i][j] = max(length[i][j-1], length[i-1][j])
                lcs[i][j] = lcs[i][j-1][:] if length[i][j-1] > length[i-1][j] else lcs[i-1][j][:]
    return length[-1][-1], lcs[-1][-1]


n = int(sys.stdin.readline())
x = list(map(str, sys.stdin.readline().split()))
m = int(sys.stdin.readline())
y = list(map(str, sys.stdin.readline().split()))


l, cs = LCS(x, y, n, m)
print(l)
for k in range(l):
    print(cs[k], '', end='')
print()
